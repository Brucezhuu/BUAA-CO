/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static unsigned int ng0[] = {0U, 0U};
static int ng1[] = {0, 0};
static unsigned int ng2[] = {1U, 0U};



static void Cont_80_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t7[8];
    char t22[8];
    char t36[8];
    char t43[8];
    char t75[8];
    char t87[8];
    char t96[8];
    char t104[8];
    char t136[8];
    char t150[8];
    char t166[8];
    char t174[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    int t67;
    int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    char *t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t88;
    char *t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    char *t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t118;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    int t128;
    int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    char *t143;
    char *t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    char *t148;
    char *t149;
    char *t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    char *t165;
    char *t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    char *t173;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    char *t178;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    char *t188;
    char *t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    int t198;
    int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    char *t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    char *t212;
    char *t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    char *t223;
    char *t224;
    char *t225;
    char *t226;
    char *t227;
    char *t228;

LAB0:    t1 = (t0 + 8288U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3448U);
    t5 = *((char **)t2);
    t2 = (t0 + 2808U);
    t6 = *((char **)t2);
    memset(t7, 0, 8);
    t2 = (t5 + 4);
    t8 = (t6 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t6);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t2);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t2);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t7) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t7 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t23) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4);
    t31 = *((unsigned int *)t22);
    t32 = *((unsigned int *)t30);
    t33 = (t31 || t32);
    if (t33 > 0)
        goto LAB12;

LAB13:    memcpy(t43, t22, 8);

LAB14:    memset(t75, 0, 8);
    t76 = (t43 + 4);
    t77 = *((unsigned int *)t76);
    t78 = (~(t77));
    t79 = *((unsigned int *)t43);
    t80 = (t79 & t78);
    t81 = (t80 & 1U);
    if (t81 != 0)
        goto LAB22;

LAB23:    if (*((unsigned int *)t76) != 0)
        goto LAB24;

LAB25:    t83 = (t75 + 4);
    t84 = *((unsigned int *)t75);
    t85 = *((unsigned int *)t83);
    t86 = (t84 || t85);
    if (t86 > 0)
        goto LAB26;

LAB27:    memcpy(t104, t75, 8);

LAB28:    memset(t136, 0, 8);
    t137 = (t104 + 4);
    t138 = *((unsigned int *)t137);
    t139 = (~(t138));
    t140 = *((unsigned int *)t104);
    t141 = (t140 & t139);
    t142 = (t141 & 1U);
    if (t142 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t137) != 0)
        goto LAB42;

LAB43:    t144 = (t136 + 4);
    t145 = *((unsigned int *)t136);
    t146 = *((unsigned int *)t144);
    t147 = (t145 || t146);
    if (t147 > 0)
        goto LAB44;

LAB45:    memcpy(t174, t136, 8);

LAB46:    memset(t4, 0, 8);
    t206 = (t174 + 4);
    t207 = *((unsigned int *)t206);
    t208 = (~(t207));
    t209 = *((unsigned int *)t174);
    t210 = (t209 & t208);
    t211 = (t210 & 1U);
    if (t211 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t206) != 0)
        goto LAB60;

LAB61:    t213 = (t4 + 4);
    t214 = *((unsigned int *)t4);
    t215 = *((unsigned int *)t213);
    t216 = (t214 || t215);
    if (t216 > 0)
        goto LAB62;

LAB63:    t219 = *((unsigned int *)t4);
    t220 = (~(t219));
    t221 = *((unsigned int *)t213);
    t222 = (t220 || t221);
    if (t222 > 0)
        goto LAB64;

LAB65:    if (*((unsigned int *)t213) > 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t4) > 0)
        goto LAB68;

LAB69:    memcpy(t3, t223, 8);

LAB70:    t217 = (t0 + 9464);
    t224 = (t217 + 56U);
    t225 = *((char **)t224);
    t226 = (t225 + 56U);
    t227 = *((char **)t226);
    memcpy(t227, t3, 8);
    xsi_driver_vfirst_trans(t217, 0, 31);
    t228 = (t0 + 9352);
    *((int *)t228) = 1;

LAB1:    return;
LAB6:    t21 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    t29 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB11;

LAB12:    t34 = (t0 + 2488U);
    t35 = *((char **)t34);
    memset(t36, 0, 8);
    t34 = (t35 + 4);
    t37 = *((unsigned int *)t34);
    t38 = (~(t37));
    t39 = *((unsigned int *)t35);
    t40 = (t39 & t38);
    t41 = (t40 & 1U);
    if (t41 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t34) != 0)
        goto LAB17;

LAB18:    t44 = *((unsigned int *)t22);
    t45 = *((unsigned int *)t36);
    t46 = (t44 & t45);
    *((unsigned int *)t43) = t46;
    t47 = (t22 + 4);
    t48 = (t36 + 4);
    t49 = (t43 + 4);
    t50 = *((unsigned int *)t47);
    t51 = *((unsigned int *)t48);
    t52 = (t50 | t51);
    *((unsigned int *)t49) = t52;
    t53 = *((unsigned int *)t49);
    t54 = (t53 != 0);
    if (t54 == 1)
        goto LAB19;

LAB20:
LAB21:    goto LAB14;

LAB15:    *((unsigned int *)t36) = 1;
    goto LAB18;

LAB17:    t42 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t42) = 1;
    goto LAB18;

LAB19:    t55 = *((unsigned int *)t43);
    t56 = *((unsigned int *)t49);
    *((unsigned int *)t43) = (t55 | t56);
    t57 = (t22 + 4);
    t58 = (t36 + 4);
    t59 = *((unsigned int *)t22);
    t60 = (~(t59));
    t61 = *((unsigned int *)t57);
    t62 = (~(t61));
    t63 = *((unsigned int *)t36);
    t64 = (~(t63));
    t65 = *((unsigned int *)t58);
    t66 = (~(t65));
    t67 = (t60 & t62);
    t68 = (t64 & t66);
    t69 = (~(t67));
    t70 = (~(t68));
    t71 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t71 & t69);
    t72 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t72 & t70);
    t73 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t73 & t69);
    t74 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t74 & t70);
    goto LAB21;

LAB22:    *((unsigned int *)t75) = 1;
    goto LAB25;

LAB24:    t82 = (t75 + 4);
    *((unsigned int *)t75) = 1;
    *((unsigned int *)t82) = 1;
    goto LAB25;

LAB26:    t88 = (t0 + 2968U);
    t89 = *((char **)t88);
    memset(t87, 0, 8);
    t88 = (t89 + 4);
    t90 = *((unsigned int *)t88);
    t91 = (~(t90));
    t92 = *((unsigned int *)t89);
    t93 = (t92 & t91);
    t94 = (t93 & 7U);
    if (t94 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t88) == 0)
        goto LAB29;

LAB31:    t95 = (t87 + 4);
    *((unsigned int *)t87) = 1;
    *((unsigned int *)t95) = 1;

LAB32:    memset(t96, 0, 8);
    t97 = (t87 + 4);
    t98 = *((unsigned int *)t97);
    t99 = (~(t98));
    t100 = *((unsigned int *)t87);
    t101 = (t100 & t99);
    t102 = (t101 & 1U);
    if (t102 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t97) != 0)
        goto LAB35;

LAB36:    t105 = *((unsigned int *)t75);
    t106 = *((unsigned int *)t96);
    t107 = (t105 & t106);
    *((unsigned int *)t104) = t107;
    t108 = (t75 + 4);
    t109 = (t96 + 4);
    t110 = (t104 + 4);
    t111 = *((unsigned int *)t108);
    t112 = *((unsigned int *)t109);
    t113 = (t111 | t112);
    *((unsigned int *)t110) = t113;
    t114 = *((unsigned int *)t110);
    t115 = (t114 != 0);
    if (t115 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB28;

LAB29:    *((unsigned int *)t87) = 1;
    goto LAB32;

LAB33:    *((unsigned int *)t96) = 1;
    goto LAB36;

LAB35:    t103 = (t96 + 4);
    *((unsigned int *)t96) = 1;
    *((unsigned int *)t103) = 1;
    goto LAB36;

LAB37:    t116 = *((unsigned int *)t104);
    t117 = *((unsigned int *)t110);
    *((unsigned int *)t104) = (t116 | t117);
    t118 = (t75 + 4);
    t119 = (t96 + 4);
    t120 = *((unsigned int *)t75);
    t121 = (~(t120));
    t122 = *((unsigned int *)t118);
    t123 = (~(t122));
    t124 = *((unsigned int *)t96);
    t125 = (~(t124));
    t126 = *((unsigned int *)t119);
    t127 = (~(t126));
    t128 = (t121 & t123);
    t129 = (t125 & t127);
    t130 = (~(t128));
    t131 = (~(t129));
    t132 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t132 & t130);
    t133 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t133 & t131);
    t134 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t134 & t130);
    t135 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t135 & t131);
    goto LAB39;

LAB40:    *((unsigned int *)t136) = 1;
    goto LAB43;

LAB42:    t143 = (t136 + 4);
    *((unsigned int *)t136) = 1;
    *((unsigned int *)t143) = 1;
    goto LAB43;

LAB44:    t148 = (t0 + 3448U);
    t149 = *((char **)t148);
    t148 = ((char*)((ng0)));
    memset(t150, 0, 8);
    t151 = (t149 + 4);
    t152 = (t148 + 4);
    t153 = *((unsigned int *)t149);
    t154 = *((unsigned int *)t148);
    t155 = (t153 ^ t154);
    t156 = *((unsigned int *)t151);
    t157 = *((unsigned int *)t152);
    t158 = (t156 ^ t157);
    t159 = (t155 | t158);
    t160 = *((unsigned int *)t151);
    t161 = *((unsigned int *)t152);
    t162 = (t160 | t161);
    t163 = (~(t162));
    t164 = (t159 & t163);
    if (t164 != 0)
        goto LAB48;

LAB47:    if (t162 != 0)
        goto LAB49;

LAB50:    memset(t166, 0, 8);
    t167 = (t150 + 4);
    t168 = *((unsigned int *)t167);
    t169 = (~(t168));
    t170 = *((unsigned int *)t150);
    t171 = (t170 & t169);
    t172 = (t171 & 1U);
    if (t172 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t167) != 0)
        goto LAB53;

LAB54:    t175 = *((unsigned int *)t136);
    t176 = *((unsigned int *)t166);
    t177 = (t175 & t176);
    *((unsigned int *)t174) = t177;
    t178 = (t136 + 4);
    t179 = (t166 + 4);
    t180 = (t174 + 4);
    t181 = *((unsigned int *)t178);
    t182 = *((unsigned int *)t179);
    t183 = (t181 | t182);
    *((unsigned int *)t180) = t183;
    t184 = *((unsigned int *)t180);
    t185 = (t184 != 0);
    if (t185 == 1)
        goto LAB55;

LAB56:
LAB57:    goto LAB46;

LAB48:    *((unsigned int *)t150) = 1;
    goto LAB50;

LAB49:    t165 = (t150 + 4);
    *((unsigned int *)t150) = 1;
    *((unsigned int *)t165) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t166) = 1;
    goto LAB54;

LAB53:    t173 = (t166 + 4);
    *((unsigned int *)t166) = 1;
    *((unsigned int *)t173) = 1;
    goto LAB54;

LAB55:    t186 = *((unsigned int *)t174);
    t187 = *((unsigned int *)t180);
    *((unsigned int *)t174) = (t186 | t187);
    t188 = (t136 + 4);
    t189 = (t166 + 4);
    t190 = *((unsigned int *)t136);
    t191 = (~(t190));
    t192 = *((unsigned int *)t188);
    t193 = (~(t192));
    t194 = *((unsigned int *)t166);
    t195 = (~(t194));
    t196 = *((unsigned int *)t189);
    t197 = (~(t196));
    t198 = (t191 & t193);
    t199 = (t195 & t197);
    t200 = (~(t198));
    t201 = (~(t199));
    t202 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t202 & t200);
    t203 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t203 & t201);
    t204 = *((unsigned int *)t174);
    *((unsigned int *)t174) = (t204 & t200);
    t205 = *((unsigned int *)t174);
    *((unsigned int *)t174) = (t205 & t201);
    goto LAB57;

LAB58:    *((unsigned int *)t4) = 1;
    goto LAB61;

LAB60:    t212 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t212) = 1;
    goto LAB61;

LAB62:    t217 = (t0 + 2648U);
    t218 = *((char **)t217);
    goto LAB63;

LAB64:    t217 = (t0 + 4888U);
    t223 = *((char **)t217);
    goto LAB65;

LAB66:    xsi_vlog_unsigned_bit_combine(t3, 32, t218, 32, t223, 32);
    goto LAB70;

LAB68:    memcpy(t3, t218, 8);
    goto LAB70;

}

static void Cont_81_1(char *t0)
{
    char t3[8];
    char t4[8];
    char t7[8];
    char t22[8];
    char t36[8];
    char t43[8];
    char t75[8];
    char t87[8];
    char t96[8];
    char t104[8];
    char t136[8];
    char t150[8];
    char t166[8];
    char t174[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    char *t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    int t67;
    int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    char *t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    char *t82;
    char *t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t88;
    char *t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    char *t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t118;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    int t128;
    int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    char *t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    char *t143;
    char *t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    char *t148;
    char *t149;
    char *t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    char *t165;
    char *t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    char *t173;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    char *t178;
    char *t179;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    char *t188;
    char *t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    int t198;
    int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    char *t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    char *t212;
    char *t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    char *t223;
    char *t224;
    char *t225;
    char *t226;
    char *t227;
    char *t228;

LAB0:    t1 = (t0 + 8536U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3608U);
    t5 = *((char **)t2);
    t2 = (t0 + 2808U);
    t6 = *((char **)t2);
    memset(t7, 0, 8);
    t2 = (t5 + 4);
    t8 = (t6 + 4);
    t9 = *((unsigned int *)t5);
    t10 = *((unsigned int *)t6);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t2);
    t13 = *((unsigned int *)t8);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t2);
    t17 = *((unsigned int *)t8);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB7;

LAB4:    if (t18 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t7) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t7 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t7);
    t27 = (t26 & t25);
    t28 = (t27 & 1U);
    if (t28 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t23) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4);
    t31 = *((unsigned int *)t22);
    t32 = *((unsigned int *)t30);
    t33 = (t31 || t32);
    if (t33 > 0)
        goto LAB12;

LAB13:    memcpy(t43, t22, 8);

LAB14:    memset(t75, 0, 8);
    t76 = (t43 + 4);
    t77 = *((unsigned int *)t76);
    t78 = (~(t77));
    t79 = *((unsigned int *)t43);
    t80 = (t79 & t78);
    t81 = (t80 & 1U);
    if (t81 != 0)
        goto LAB22;

LAB23:    if (*((unsigned int *)t76) != 0)
        goto LAB24;

LAB25:    t83 = (t75 + 4);
    t84 = *((unsigned int *)t75);
    t85 = *((unsigned int *)t83);
    t86 = (t84 || t85);
    if (t86 > 0)
        goto LAB26;

LAB27:    memcpy(t104, t75, 8);

LAB28:    memset(t136, 0, 8);
    t137 = (t104 + 4);
    t138 = *((unsigned int *)t137);
    t139 = (~(t138));
    t140 = *((unsigned int *)t104);
    t141 = (t140 & t139);
    t142 = (t141 & 1U);
    if (t142 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t137) != 0)
        goto LAB42;

LAB43:    t144 = (t136 + 4);
    t145 = *((unsigned int *)t136);
    t146 = *((unsigned int *)t144);
    t147 = (t145 || t146);
    if (t147 > 0)
        goto LAB44;

LAB45:    memcpy(t174, t136, 8);

LAB46:    memset(t4, 0, 8);
    t206 = (t174 + 4);
    t207 = *((unsigned int *)t206);
    t208 = (~(t207));
    t209 = *((unsigned int *)t174);
    t210 = (t209 & t208);
    t211 = (t210 & 1U);
    if (t211 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t206) != 0)
        goto LAB60;

LAB61:    t213 = (t4 + 4);
    t214 = *((unsigned int *)t4);
    t215 = *((unsigned int *)t213);
    t216 = (t214 || t215);
    if (t216 > 0)
        goto LAB62;

LAB63:    t219 = *((unsigned int *)t4);
    t220 = (~(t219));
    t221 = *((unsigned int *)t213);
    t222 = (t220 || t221);
    if (t222 > 0)
        goto LAB64;

LAB65:    if (*((unsigned int *)t213) > 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t4) > 0)
        goto LAB68;

LAB69:    memcpy(t3, t223, 8);

LAB70:    t217 = (t0 + 9528);
    t224 = (t217 + 56U);
    t225 = *((char **)t224);
    t226 = (t225 + 56U);
    t227 = *((char **)t226);
    memcpy(t227, t3, 8);
    xsi_driver_vfirst_trans(t217, 0, 31);
    t228 = (t0 + 9368);
    *((int *)t228) = 1;

LAB1:    return;
LAB6:    t21 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    t29 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t29) = 1;
    goto LAB11;

LAB12:    t34 = (t0 + 2488U);
    t35 = *((char **)t34);
    memset(t36, 0, 8);
    t34 = (t35 + 4);
    t37 = *((unsigned int *)t34);
    t38 = (~(t37));
    t39 = *((unsigned int *)t35);
    t40 = (t39 & t38);
    t41 = (t40 & 1U);
    if (t41 != 0)
        goto LAB15;

LAB16:    if (*((unsigned int *)t34) != 0)
        goto LAB17;

LAB18:    t44 = *((unsigned int *)t22);
    t45 = *((unsigned int *)t36);
    t46 = (t44 & t45);
    *((unsigned int *)t43) = t46;
    t47 = (t22 + 4);
    t48 = (t36 + 4);
    t49 = (t43 + 4);
    t50 = *((unsigned int *)t47);
    t51 = *((unsigned int *)t48);
    t52 = (t50 | t51);
    *((unsigned int *)t49) = t52;
    t53 = *((unsigned int *)t49);
    t54 = (t53 != 0);
    if (t54 == 1)
        goto LAB19;

LAB20:
LAB21:    goto LAB14;

LAB15:    *((unsigned int *)t36) = 1;
    goto LAB18;

LAB17:    t42 = (t36 + 4);
    *((unsigned int *)t36) = 1;
    *((unsigned int *)t42) = 1;
    goto LAB18;

LAB19:    t55 = *((unsigned int *)t43);
    t56 = *((unsigned int *)t49);
    *((unsigned int *)t43) = (t55 | t56);
    t57 = (t22 + 4);
    t58 = (t36 + 4);
    t59 = *((unsigned int *)t22);
    t60 = (~(t59));
    t61 = *((unsigned int *)t57);
    t62 = (~(t61));
    t63 = *((unsigned int *)t36);
    t64 = (~(t63));
    t65 = *((unsigned int *)t58);
    t66 = (~(t65));
    t67 = (t60 & t62);
    t68 = (t64 & t66);
    t69 = (~(t67));
    t70 = (~(t68));
    t71 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t71 & t69);
    t72 = *((unsigned int *)t49);
    *((unsigned int *)t49) = (t72 & t70);
    t73 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t73 & t69);
    t74 = *((unsigned int *)t43);
    *((unsigned int *)t43) = (t74 & t70);
    goto LAB21;

LAB22:    *((unsigned int *)t75) = 1;
    goto LAB25;

LAB24:    t82 = (t75 + 4);
    *((unsigned int *)t75) = 1;
    *((unsigned int *)t82) = 1;
    goto LAB25;

LAB26:    t88 = (t0 + 2968U);
    t89 = *((char **)t88);
    memset(t87, 0, 8);
    t88 = (t89 + 4);
    t90 = *((unsigned int *)t88);
    t91 = (~(t90));
    t92 = *((unsigned int *)t89);
    t93 = (t92 & t91);
    t94 = (t93 & 7U);
    if (t94 != 0)
        goto LAB32;

LAB30:    if (*((unsigned int *)t88) == 0)
        goto LAB29;

LAB31:    t95 = (t87 + 4);
    *((unsigned int *)t87) = 1;
    *((unsigned int *)t95) = 1;

LAB32:    memset(t96, 0, 8);
    t97 = (t87 + 4);
    t98 = *((unsigned int *)t97);
    t99 = (~(t98));
    t100 = *((unsigned int *)t87);
    t101 = (t100 & t99);
    t102 = (t101 & 1U);
    if (t102 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t97) != 0)
        goto LAB35;

LAB36:    t105 = *((unsigned int *)t75);
    t106 = *((unsigned int *)t96);
    t107 = (t105 & t106);
    *((unsigned int *)t104) = t107;
    t108 = (t75 + 4);
    t109 = (t96 + 4);
    t110 = (t104 + 4);
    t111 = *((unsigned int *)t108);
    t112 = *((unsigned int *)t109);
    t113 = (t111 | t112);
    *((unsigned int *)t110) = t113;
    t114 = *((unsigned int *)t110);
    t115 = (t114 != 0);
    if (t115 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB28;

LAB29:    *((unsigned int *)t87) = 1;
    goto LAB32;

LAB33:    *((unsigned int *)t96) = 1;
    goto LAB36;

LAB35:    t103 = (t96 + 4);
    *((unsigned int *)t96) = 1;
    *((unsigned int *)t103) = 1;
    goto LAB36;

LAB37:    t116 = *((unsigned int *)t104);
    t117 = *((unsigned int *)t110);
    *((unsigned int *)t104) = (t116 | t117);
    t118 = (t75 + 4);
    t119 = (t96 + 4);
    t120 = *((unsigned int *)t75);
    t121 = (~(t120));
    t122 = *((unsigned int *)t118);
    t123 = (~(t122));
    t124 = *((unsigned int *)t96);
    t125 = (~(t124));
    t126 = *((unsigned int *)t119);
    t127 = (~(t126));
    t128 = (t121 & t123);
    t129 = (t125 & t127);
    t130 = (~(t128));
    t131 = (~(t129));
    t132 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t132 & t130);
    t133 = *((unsigned int *)t110);
    *((unsigned int *)t110) = (t133 & t131);
    t134 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t134 & t130);
    t135 = *((unsigned int *)t104);
    *((unsigned int *)t104) = (t135 & t131);
    goto LAB39;

LAB40:    *((unsigned int *)t136) = 1;
    goto LAB43;

LAB42:    t143 = (t136 + 4);
    *((unsigned int *)t136) = 1;
    *((unsigned int *)t143) = 1;
    goto LAB43;

LAB44:    t148 = (t0 + 3608U);
    t149 = *((char **)t148);
    t148 = ((char*)((ng0)));
    memset(t150, 0, 8);
    t151 = (t149 + 4);
    t152 = (t148 + 4);
    t153 = *((unsigned int *)t149);
    t154 = *((unsigned int *)t148);
    t155 = (t153 ^ t154);
    t156 = *((unsigned int *)t151);
    t157 = *((unsigned int *)t152);
    t158 = (t156 ^ t157);
    t159 = (t155 | t158);
    t160 = *((unsigned int *)t151);
    t161 = *((unsigned int *)t152);
    t162 = (t160 | t161);
    t163 = (~(t162));
    t164 = (t159 & t163);
    if (t164 != 0)
        goto LAB48;

LAB47:    if (t162 != 0)
        goto LAB49;

LAB50:    memset(t166, 0, 8);
    t167 = (t150 + 4);
    t168 = *((unsigned int *)t167);
    t169 = (~(t168));
    t170 = *((unsigned int *)t150);
    t171 = (t170 & t169);
    t172 = (t171 & 1U);
    if (t172 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t167) != 0)
        goto LAB53;

LAB54:    t175 = *((unsigned int *)t136);
    t176 = *((unsigned int *)t166);
    t177 = (t175 & t176);
    *((unsigned int *)t174) = t177;
    t178 = (t136 + 4);
    t179 = (t166 + 4);
    t180 = (t174 + 4);
    t181 = *((unsigned int *)t178);
    t182 = *((unsigned int *)t179);
    t183 = (t181 | t182);
    *((unsigned int *)t180) = t183;
    t184 = *((unsigned int *)t180);
    t185 = (t184 != 0);
    if (t185 == 1)
        goto LAB55;

LAB56:
LAB57:    goto LAB46;

LAB48:    *((unsigned int *)t150) = 1;
    goto LAB50;

LAB49:    t165 = (t150 + 4);
    *((unsigned int *)t150) = 1;
    *((unsigned int *)t165) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t166) = 1;
    goto LAB54;

LAB53:    t173 = (t166 + 4);
    *((unsigned int *)t166) = 1;
    *((unsigned int *)t173) = 1;
    goto LAB54;

LAB55:    t186 = *((unsigned int *)t174);
    t187 = *((unsigned int *)t180);
    *((unsigned int *)t174) = (t186 | t187);
    t188 = (t136 + 4);
    t189 = (t166 + 4);
    t190 = *((unsigned int *)t136);
    t191 = (~(t190));
    t192 = *((unsigned int *)t188);
    t193 = (~(t192));
    t194 = *((unsigned int *)t166);
    t195 = (~(t194));
    t196 = *((unsigned int *)t189);
    t197 = (~(t196));
    t198 = (t191 & t193);
    t199 = (t195 & t197);
    t200 = (~(t198));
    t201 = (~(t199));
    t202 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t202 & t200);
    t203 = *((unsigned int *)t180);
    *((unsigned int *)t180) = (t203 & t201);
    t204 = *((unsigned int *)t174);
    *((unsigned int *)t174) = (t204 & t200);
    t205 = *((unsigned int *)t174);
    *((unsigned int *)t174) = (t205 & t201);
    goto LAB57;

LAB58:    *((unsigned int *)t4) = 1;
    goto LAB61;

LAB60:    t212 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t212) = 1;
    goto LAB61;

LAB62:    t217 = (t0 + 2648U);
    t218 = *((char **)t217);
    goto LAB63;

LAB64:    t217 = (t0 + 5048U);
    t223 = *((char **)t217);
    goto LAB65;

LAB66:    xsi_vlog_unsigned_bit_combine(t3, 32, t218, 32, t223, 32);
    goto LAB70;

LAB68:    memcpy(t3, t218, 8);
    goto LAB70;

}

static void Initial_103_2(char *t0)
{
    char *t1;
    char *t2;

LAB0:
LAB2:    t1 = ((char*)((ng1)));
    t2 = (t0 + 5928);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 18);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 6088);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 6248);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 6408);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 5);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 6568);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 5);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 7048);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 5);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 6728);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 7208);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 3);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 7368);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);
    t1 = ((char*)((ng0)));
    t2 = (t0 + 6888);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);

LAB1:    return;
}

static void Always_117_3(char *t0)
{
    char t7[8];
    char t42[8];
    char t43[8];
    char t44[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    char *t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;

LAB0:    t1 = (t0 + 9032U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 9384);
    *((int *)t2) = 1;
    t3 = (t0 + 9064);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t0 + 3288U);
    t6 = *((char **)t4);
    t8 = *((unsigned int *)t5);
    t9 = *((unsigned int *)t6);
    t10 = (t8 | t9);
    *((unsigned int *)t7) = t10;
    t4 = (t5 + 4);
    t11 = (t6 + 4);
    t12 = (t7 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t11);
    t15 = (t13 | t14);
    *((unsigned int *)t12) = t15;
    t16 = *((unsigned int *)t12);
    t17 = (t16 != 0);
    if (t17 == 1)
        goto LAB6;

LAB7:
LAB8:    t34 = (t7 + 4);
    t35 = *((unsigned int *)t34);
    t36 = (~(t35));
    t37 = *((unsigned int *)t7);
    t38 = (t37 & t36);
    t39 = (t38 != 0);
    if (t39 > 0)
        goto LAB9;

LAB10:
LAB13:    t2 = (t0 + 4088U);
    t3 = *((char **)t2);
    t2 = (t0 + 5928);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 18, 0LL);
    t2 = (t0 + 4888U);
    t3 = *((char **)t2);
    t2 = (t0 + 6088);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    t2 = (t0 + 5048U);
    t3 = *((char **)t2);
    t2 = (t0 + 6248);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    t2 = (t0 + 3448U);
    t3 = *((char **)t2);
    t2 = (t0 + 6408);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 5, 0LL);
    t2 = (t0 + 3608U);
    t3 = *((char **)t2);
    t2 = (t0 + 6568);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 5, 0LL);
    t2 = (t0 + 4568U);
    t3 = *((char **)t2);
    t2 = (t0 + 7048);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 5, 0LL);
    t2 = (t0 + 4728U);
    t3 = *((char **)t2);
    t2 = (t0 + 6728);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 1, 0LL);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 7368);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t0 + 6888);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    t2 = (t0 + 5528U);
    t3 = *((char **)t2);
    memset(t43, 0, 8);
    t2 = (t3 + 4);
    t8 = *((unsigned int *)t2);
    t9 = (~(t8));
    t10 = *((unsigned int *)t3);
    t13 = (t10 & t9);
    t14 = (t13 & 7U);
    if (t14 != 0)
        goto LAB17;

LAB15:    if (*((unsigned int *)t2) == 0)
        goto LAB14;

LAB16:    t4 = (t43 + 4);
    *((unsigned int *)t43) = 1;
    *((unsigned int *)t4) = 1;

LAB17:    memset(t42, 0, 8);
    t5 = (t43 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (~(t15));
    t17 = *((unsigned int *)t43);
    t18 = (t17 & t16);
    t19 = (t18 & 1U);
    if (t19 != 0)
        goto LAB18;

LAB19:    if (*((unsigned int *)t5) != 0)
        goto LAB20;

LAB21:    t11 = (t42 + 4);
    t22 = *((unsigned int *)t42);
    t23 = *((unsigned int *)t11);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB22;

LAB23:    t26 = *((unsigned int *)t42);
    t27 = (~(t26));
    t28 = *((unsigned int *)t11);
    t30 = (t27 || t28);
    if (t30 > 0)
        goto LAB24;

LAB25:    if (*((unsigned int *)t11) > 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t42) > 0)
        goto LAB28;

LAB29:    memcpy(t7, t44, 8);

LAB30:    t34 = (t0 + 7208);
    xsi_vlogvar_wait_assign_value(t34, t7, 0, 0, 3, 0LL);

LAB11:    goto LAB2;

LAB6:    t18 = *((unsigned int *)t7);
    t19 = *((unsigned int *)t12);
    *((unsigned int *)t7) = (t18 | t19);
    t20 = (t5 + 4);
    t21 = (t6 + 4);
    t22 = *((unsigned int *)t20);
    t23 = (~(t22));
    t24 = *((unsigned int *)t5);
    t25 = (t24 & t23);
    t26 = *((unsigned int *)t21);
    t27 = (~(t26));
    t28 = *((unsigned int *)t6);
    t29 = (t28 & t27);
    t30 = (~(t25));
    t31 = (~(t29));
    t32 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t32 & t30);
    t33 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t33 & t31);
    goto LAB8;

LAB9:
LAB12:    t40 = ((char*)((ng0)));
    t41 = (t0 + 5928);
    xsi_vlogvar_wait_assign_value(t41, t40, 0, 0, 18, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 6088);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 6248);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 6408);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 6568);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 7048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 5, 0LL);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 6728);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 7208);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 3, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 7368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 6888);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 32, 0LL);
    goto LAB11;

LAB14:    *((unsigned int *)t43) = 1;
    goto LAB17;

LAB18:    *((unsigned int *)t42) = 1;
    goto LAB21;

LAB20:    t6 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t6) = 1;
    goto LAB21;

LAB22:    t12 = ((char*)((ng0)));
    goto LAB23;

LAB24:    t20 = (t0 + 5528U);
    t21 = *((char **)t20);
    t20 = ((char*)((ng2)));
    memset(t44, 0, 8);
    xsi_vlog_unsigned_minus(t44, 3, t21, 3, t20, 3);
    goto LAB25;

LAB26:    xsi_vlog_unsigned_bit_combine(t7, 3, t12, 3, t44, 3);
    goto LAB30;

LAB28:    memcpy(t7, t12, 8);
    goto LAB30;

}


extern void work_m_00000000002838432375_0103510313_init()
{
	static char *pe[] = {(void *)Cont_80_0,(void *)Cont_81_1,(void *)Initial_103_2,(void *)Always_117_3};
	xsi_register_didat("work_m_00000000002838432375_0103510313", "isim/testX.exe.sim/work/m_00000000002838432375_0103510313.didat");
	xsi_register_executes(pe);
}
